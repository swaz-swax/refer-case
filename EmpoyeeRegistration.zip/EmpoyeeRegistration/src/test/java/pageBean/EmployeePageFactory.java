package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class EmployeePageFactory {
	WebDriver driver;
	
	
	@FindBy(name="txtEN")
	@CacheLookup
	WebElement pfename;
	
	@FindBy(how=How.ID, using="btnPayment")
	@CacheLookup
	WebElement pfbutton;
	
	@FindBy(xpath="//*[@id='txtDesignation']")
	@CacheLookup
	WebElement pfdesig;
	
	@FindBy(how=How.ID, using="txtSalary")
	@CacheLookup
	WebElement pfsal;

	@FindBy(id="txtDepartment")
	@CacheLookup
	WebElement pfdept;
	
	public void setPfename(String sename) {
		pfename.sendKeys(sename);
	}

	public void setPfbutton() {
		pfbutton.click();
	}

	
	
	public void setPfdesig(String sdesig) {
		pfdesig.sendKeys(sdesig);
	}
	
	public void setPfsal(String ssal) {
		pfsal.sendKeys(ssal);
	}
	
	public void setPfdept(String sdept) {
		pfdept.sendKeys(sdept);
	}

	public WebElement getPfename() {
		return pfename;
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public WebElement getPfdesig() {
		return pfdesig;
	}

	public WebElement getPfsal() {
		return pfsal;
	}

	public WebElement getPfdept() {
		return pfdept;
	}
	
	//initiating Elements
		public EmployeePageFactory(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
}
