package EmployeeDetails;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.EmployeePageFactory;

public class EmployeeStepDef {
	private static WebDriver driver;
	private EmployeePageFactory obj;
	String BaseURL, NodeURL;

	@Before
	public void beforeLogin() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^User is on 'Employee Registration' Page$")
	public void user_is_on_Employee_Registration_Page() throws Throwable {
		System.out.println("driver = " + driver);
		obj = new EmployeePageFactory(driver);

		driver.get("file:///C:/Users/admin/Documents/keerthana/M3/Employee%20Registration.htm");
	}

	@When("^user gives empty Employee Name$")
	public void user_gives_empty_Employee_Name() throws Throwable {
		obj.setPfename("");
		obj.setPfbutton();
	}

	@Then("^display 'Please fill the Employee Name'$")
	public void display_Please_fill_the_Employee_Name() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Employee Name");

	}

	@When("^user gives empty Designation$")
	public void user_gives_empty_Designation() throws Throwable {
		obj.setPfename("Keerthana");
		obj.setPfdesig("");
		obj.setPfbutton();
	}

	@Then("^display 'Please fill the Designation'$")
	public void display_Please_fill_the_Designation() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Designation");

	}

	@When("^user gives empty Salary$")
	public void user_gives_empty_Salary() throws Throwable {
		obj.setPfename("Keerthana");
		obj.setPfdesig("Analyst");
		obj.setPfsal("");
		obj.setPfbutton();
	}

	@Then("^display 'Please fill the Salary'$")
	public void display_Please_fill_the_Salary() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Salary");

	}

	@When("^user gives empty Department$")
	public void user_gives_empty_Department() throws Throwable {
		obj.setPfename("Keerthana");
		obj.setPfdesig("Analyst");
		obj.setPfsal("20000");
		obj.setPfdept("");
		obj.setPfbutton();
	}

	@Then("^display 'Please fill the Department'$")
	public void display_Please_fill_the_Department() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Department");

	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		obj.setPfename("Keerthana");
		obj.setPfdesig("Analyst");
		obj.setPfsal("20000");
		obj.setPfdept("Java");
		obj.setPfbutton();
	}

	@Then("^display 'success' Page$")
	public void display_success_Page() throws Throwable {
		driver.get("file:///C:/Users/admin/Documents/keerthana/M3/success.html");

	}

	@When("^user gives invalid Employee Name$")
	public void user_gives_invalid_Employee_Name() throws Throwable {
		obj.setPfename("123");
		obj.setPfbutton();

	}

	@Then("^display 'Please fill the valid Employee Name'$")
	public void display_Please_fill_the_valid_Employee_Name() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid name");

	}

	@When("^user gives invalid Designation$")
	public void user_gives_invalid_Designation() throws Throwable {
		obj.setPfename("Keerthana");
		obj.setPfdesig("987");
		obj.setPfbutton();

	}

	@Then("^display 'Please fill the valid Designation'$")
	public void display_Please_fill_the_valid_Designation() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid designation");

	}

	@When("^user gives invalid Salary$")
	public void user_gives_invalid_Salary() throws Throwable {
		obj.setPfename("Keerthana");
		obj.setPfdesig("Analyst");
		obj.setPfsal("kyduyda");
		obj.setPfbutton();

	}

	@Then("^display 'Please fill the valid Salary'$")
	public void display_Please_fill_the_valid_Salary() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid salary");

	}

	@When("^user gives invalid Department$")
	public void user_gives_invalid_Department() throws Throwable {
		obj.setPfename("Keerthana");
		obj.setPfdesig("Analyst");
		obj.setPfsal("20000");
		obj.setPfdept("?>[]=:");
		obj.setPfbutton();
	}

	@Then("^display 'Please fill the valid Department'$")
	public void display_Please_fill_the_valid_Department() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid department");

	}
}
